module.exports = {
    token: "TOKENINI YAZ", 
    prefix: "!"
}

